<?php
echo "Hello world!";
echo "<br>";
echo date('Y-m-d H:i:s');
echo "<br>";
phpinfo();
?>
