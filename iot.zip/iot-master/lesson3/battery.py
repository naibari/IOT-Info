import psutil
bat = psutil.sensors_battery()
print(bat)
